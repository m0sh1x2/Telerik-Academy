﻿namespace _02.BankAccounts
{
    public interface IWithdraw
    {
        void Withdraw(double amount);
    }
}
