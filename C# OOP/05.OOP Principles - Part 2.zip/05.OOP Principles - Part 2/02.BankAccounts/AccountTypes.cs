﻿namespace _02.BankAccounts
{
    public enum AccountTypes
    {
        deposit,
        loan,
        mortgage
    }
}
