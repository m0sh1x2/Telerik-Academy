﻿namespace _02.BankAccounts
{
    public interface IDeposit
    {
        void Deposit(double amount);
    }
}
